package com.example.yasemingurbuz.theweatherapp;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.zip.DataFormatException;

import date.JSONWeatherParser;
import date.WeatherHttpClient;
import model.Weather;

public class MainActivity extends AppCompatActivity {
    private TextView cityName;
    private TextView temp;
    private ImageView iconView;
    private TextView description;
    private TextView humididty;
    private TextView pressure;
    private TextView wind;
    private TextView sunrise;
    private TextView sunset;
    private TextView updated;

    Weather weather = new Weather();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cityName = (TextView) findViewById(R.id.cityText);
        iconView = (ImageView)findViewById(R.id.thumbnailIcon);
        temp = (TextView) findViewById(R.id.tempText);
        humididty = (TextView) findViewById(R.id.humidText);
        pressure = (TextView) findViewById(R.id.pressureText);
        sunrise= (TextView) findViewById(R.id.riseText);
        sunset = (TextView) findViewById(R.id.setText);
        updated= (TextView) findViewById(R.id.updateText);

        renderWeatherData("Istanbul,TR");


    }

    public void renderWeatherData (String city){
        WeatherTask weatherTask = new WeatherTask();
        weatherTask.execute(new String[]{city+"&units=metric"});

    }

    private class DowloadImageAsyncTask extends AsyncTask<String,Void,Bitmap> {

        @Override
        protected Bitmap doInBackground(String... strings) {
            return null;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
        }


    }


    private class WeatherTask extends AsyncTask<String, Void, Weather> {
        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(Weather weather) {
            super.onPostExecute(weather);
            DateFormat df  = DateFormat.getDateTimeInstance();
            String sunriseDate = df.format(new Date(weather.place.getSunrice()));
            String sunsetDate = df.format(new Date(weather.place.getSunset())) ;
            String updateDate = df.format(new Date(weather.place.getLastupdate()));
            DecimalFormat decimalFormat = new DecimalFormat("#.#");
            String tempFormat= decimalFormat.format(weather.currentCondition.getTemperature());

            cityName.setText(weather.place.getCity()+","+weather.place.getCountry());
            temp.setText(""+ tempFormat+ "C");
            humididty.setText("humidity:" + weather.currentCondition.getHumidity()+"½");
            pressure.setText(("Pressure:"+weather.currentCondition.getPressure()+"Hpa"));
            wind.setText("Wind:" + weather.wind.getSpeed()+"mps");
            sunrise.setText("Sunrise"+ sunriseDate);
            sunset.setText("Sunset:"+sunsetDate);
            updated.setText("Last Updated:"+ updateDate);
            description.setText("Condition:"+weather.currentCondition.getCondition()+"(" + weather.currentCondition.getDiscription()+")");

        }

        @Override
        protected Weather doInBackground(String... strings) {
            String data = ( (new WeatherHttpClient()).getWeatherData(strings[0]));
            weather = JSONWeatherParser.getWeather("data");
            Log.v("Data:",weather.place.getCity());


            return weather;
        }
    }
}
