package com.example.yasemingurbuz.theweatherapp;

class R {
}
